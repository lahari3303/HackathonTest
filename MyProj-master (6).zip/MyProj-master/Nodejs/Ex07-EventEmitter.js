//how to create events in Nodejs. 
//Events are actions performed by the user on the Application or a Window or a button or a class. 
//Events have to be registered, provide a event handler and the raise(trigger) the event at appropriate situation.
//In Nodejs we have a module called events thru which we can create Events, raise events and provide handlers to the events. 
const emitter = require("events");

const eventClass = new emitter();

eventClass.on("insert", ()=>{
    console.log("Insertion event was triggered");
})
eventClass.on("delete", ()=>{
  console.log("Delete event has triggered");
});

eventClass.on("click", (func)=>{
    func();
})
eventClass.emit("delete");//raising the event called delete

eventClass.emit("insert");
eventClass.emit("insert");
eventClass.emit("insert");
eventClass.emit("insert");

function onClick(){
    console.log("The button was clicked");
}
eventClass.emit("click", onClick);