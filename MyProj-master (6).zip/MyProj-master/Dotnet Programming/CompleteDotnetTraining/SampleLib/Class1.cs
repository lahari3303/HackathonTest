﻿using System;

namespace SampleLib
{
    public class MathComponent
    {
        public double AddFunc(double v1, double v2) => v1 + v2;
    }
}
