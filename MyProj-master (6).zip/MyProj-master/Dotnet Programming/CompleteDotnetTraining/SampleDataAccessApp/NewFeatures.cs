﻿using System;
using System.Collections.Generic;

namespace SampleDataAccessApp
{
    class Customer
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress => "Bangalore";
    }
    static class MyExtensions
    {
        public static int GetNoOfWords(this string obj)
        {
            var words = obj.Split(' ');
            return words.Length;
        }
    }
    class NewFeatures
    {
        static void Main(string[] args)
        {
            //varKeyword();
            //anonymousTypes();
            //extensionMethods();
            //lambdaExpressions();
            //automaticProperties();
        }

        private static void automaticProperties()
        {
            //Object initialization syntax of C# 3.5
            var obj = new Customer { CustomerId = 123, CustomerName = "SampleName" };
            Console.WriteLine(obj.CustomerName);
        }

        private static void lambdaExpressions()
        {
            List<string> data = new List<string>("var is the new keyword introduced in .NET 3.5. It is used to refer local scoped variables. It cannot be used as a return type or as parameters for the functions. They are simply a convinient way of creating local variables. Unlike object, U dont need to box or unbox the data when storing in a var. var implicitly holds the type of the variable that it is assigned to. So var is also called as IMPLICITLY TYPED LOCAL VARIABLES. var should be assigned at the declaration statement itself. var is used widely in LINQ, Anonymous Types and other new features of .NET. ".Split(' '));

            var founddata = data.FindAll((str) => str == "the");
            foreach (var item in founddata)
            {
                Console.WriteLine(item);
            }
        }

        private static void extensionMethods()
        {
            string content = "var is the new keyword introduced in .NET 3.5. It is used to refer local scoped variables. It cannot be used as a return type or as parameters for the functions. They are simply a convinient way of creating local variables.             Unlike object, U dont need to box or unbox the data when storing in a var.             var implicitly holds the type of the variable that it is assigned to. So var is also called as IMPLICITLY TYPED LOCAL VARIABLES. var should be assigned at the declaration statement itself. var is used widely in LINQ, Anonymous Types and other new features of .NET. ";
            Console.WriteLine("The total no of words: " + content.GetNoOfWords());
        }

        private static void varKeyword()
        {
            //var is the new keyword introduced in .NET 3.5. It is used to refer local scoped variables. It cannot be used as a return type or as parameters for the functions. They are simply a convinient way of creating local variables. 
            //Unlike object, U dont need to box or unbox the data when storing in a var. 
            //var implicitly holds the type of the variable that it is assigned to. So var is also called as IMPLICITLY TYPED LOCAL VARIABLES.
            //var should be assigned at the declaration statement itself. 
           // var is used widely in LINQ, Anonymous Types and other new features of .NET. 
            var apples = 123.45f;//appples will be string. 
            Console.WriteLine(apples);
        }

        private static void anonymousTypes()
        {
            var data = new
            {
                EmpId = 123, EmpName = "Phaniraj", EmpAddress = "Bangalore"
            };

            var data2 = new
            {
                EmpId = 123,
                EmpName = "Phaniraj",
                EmpAddress = "Bangalore"
            };
            var data3 = data;
            Console.WriteLine(data == data3);
        }
    }
}