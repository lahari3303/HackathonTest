﻿using SampleDataAccessApp.Practical.Dalayer;
using SampleDataAccessApp.Practical.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleDataAccessApp.Practical
{
    class DisconnectedComponent : IDataAccessComponent
    {
        private DataSet dataSet = new DataSet("AllRecords");
        SqlDataAdapter ada = null;
        string query = "SELECT * FROM TBLEMPLOYEE; SELECT * FROM TBLDEPT";
        string strConnection = ConfigurationManager.ConnectionStrings["myConnection"].ConnectionString;
        public DisconnectedComponent()
        {
            ada = new SqlDataAdapter(query, strConnection);
            ada.Fill(dataSet);
            dataSet.Tables[0].TableName = "EmpList";
            dataSet.Tables[1].TableName = "DeptList";
        }
        public void AddNewEmployee(Employee emp)
        {
            throw new NotImplementedException();
        }

        public void DeleteEmployee(int id)
        {
            throw new NotImplementedException();
        }

        public List<Dept> GetAllDepts()
        {
            throw new NotImplementedException();
        }

        public List<Employee> GetAllEmployees()
        {
            throw new NotImplementedException();
        }

        public void UpdateEmployee(Employee emp)
        {
            throw new NotImplementedException();
        }
    }
}
