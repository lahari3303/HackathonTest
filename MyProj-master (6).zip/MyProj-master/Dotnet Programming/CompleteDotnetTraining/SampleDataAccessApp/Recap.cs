﻿using System;
using System.Data.SqlClient;

class AllData
{
    public  int data1 = 123;
    public  double data2 = 234.45;
    public string data3 = "Phaniraj";
    public string data4 = "Bangalore";
}
class Program
{
    static void Main(string[] args)
    {
      
    }
}