﻿//U can create Database Apps without the actual tables. U can first create the Entity classes and then allow the EF to generate the tables required for ur Application. 

using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace SampleDataAccessApp.DataModels
{
    public class Movie
    {
        public int MovieId { get; set; }
        public string Title{ get; set; }
        public int Duration { get; set; }
        public int DirectorId { get; set; }

        public Director Director { get; set; }
    }

    public class Director
    {
        public int DirectorId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public ICollection<Movie> Movies { get; set; }
    }
    public partial class MoviesDb : DbContext
    {
        public MoviesDb()
            : base("name=DataDb")
        {
        }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }

        public DbSet<Movie> Movies { get; set; }
        public DbSet<Director> Directors { get; set; }
    }
    class CodeFirstMain
    {
        static void Main(string[] args)
        {
            addingMovie();
            //getAllMovies(2);
            //update, delete, findByTitle
            getAllMoviesWithDirectorName();

        }

        private static void getAllMoviesWithDirectorName()
        {
            var context = new MoviesDb();
            var records = from movie in context.Movies.Include((m) => m.Director)
                          select new
                          {
                              Title = movie.Title,
                              Director = movie.Director.Name
                          };
            foreach (var rec in records) Console.WriteLine(rec);
        }

        private static void getAllMovies(int dirId)
        {
            var context = new MoviesDb();
            var director = context.Directors.Include(d => d.Movies).FirstOrDefault((d) => d.DirectorId == dirId);
            if(director.Movies != null)
            {
                foreach(var movie in director.Movies)
                { 
                    Console.WriteLine(movie.Title);
                }
            }
        }

        private static void addingMovie()
        {
            var context = new Model1();

            context.Directors.Add(new Director
            {
                DirectorId = 2,
                Name = "Maniratnam"
            });
            context.SaveChanges();
            context.Movies.Add(new Movie
            {
                MovieId = 4,
                DirectorId = 2,
                Duration = 145,
                Title = "Anjali"
            });
            context.SaveChanges();
        }
    }
}