﻿using System;
namespace SampleDataAccessApp
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
