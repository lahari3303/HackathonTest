# Serialization Assignment
- Develop an Application in Console Environment to manage the data related to Customers of a Shopping Complex. 
- The Customer information should be stored in the Xml Format using Xml Serialization. 
- It will have all the CRUD operations for the customer data. 
- It should be a Menu driven Program where the inputs will be available from the User. 
- All the Stds of the programming must be implemented. 