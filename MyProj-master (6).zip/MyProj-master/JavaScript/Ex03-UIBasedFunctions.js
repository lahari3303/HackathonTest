alert("Message from the App to the user")

const answer = prompt("Please enter your Name");
console.log(answer);

//confirm returns true or false for OK and cancel respectively..
if(confirm("Do U really want to try this?"))
{
    alert("He is good");
}else{
    alert("Should need more practise to try!!!")
}


//Exersise: Create a Program in JS to do the Temperature conversion App.
//The App takes the input in celceius and should display the converted value of Farenheit in a alert box. 
